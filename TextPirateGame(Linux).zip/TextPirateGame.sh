#!/bin/bash
java -jar TextPirateGame.jar
