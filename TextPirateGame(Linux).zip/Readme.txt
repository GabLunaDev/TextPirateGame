To execute this game you need open your terminal with right click in this directory and put this command:

"bash TextPirateGame.sh"